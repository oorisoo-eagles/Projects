import java.util.*;
/**
 * MyBoundedGrid class creates a grid with row and column features
 * that hold a series of locations where objects can be placed
 *
 * @author Risa Chokhawala
 * @version March 25, 2024
 */
public class MyBoundedGrid<E>
{
    private int numRows;
    private int numCols;
    private Object[][]  occupantArray;
    /**
     * creates a MyBoundedGrid object
     * @param rows number of rows in grid
     * @param cols number of cols in grid
     */
    public MyBoundedGrid (int rows, int cols)
    {
        numRows = rows;
        numCols = cols;
        occupantArray = new Object[rows][cols];
    }

    /**
     * get number of rows of MyBoundedGrid object
     *
     * @return    the number of rows
     */
    public int getNumRows()
    {
        return numRows;
    }
    
    /**
     * get number of cols of MyBoundedGrid object
     *
     * @return    the number of rows
     */
    public int getNumCols()
    {
        return numCols;
    }
    
    /**
     * checks if Location "loc" is valid MyBoundedGrid
     * @param loc the location that will be checked
     * @return true if loc is valid and false if it isn't
     */
    public boolean isValid(Location loc)
    {   
        if((loc.getRow() < numRows && loc.getRow() >= 0) && 
            (loc.getCol() < numCols && loc.getCol() >= 0))
        {
            return true;
        }
        return false;
    }
    
    /**
     * puts obj on Location "loc" on MyBoundedGrid
     * @param loc the location where obj should go
     * @param obj the obj that should be added to MyBoundedGrid at loc
     * @return previous object at location or null if location 
     * was previously unoccupied
     */
    public E put(Location loc, E obj)
    {
        if(!isValid(loc))
        {
            throw new RuntimeException("location is in valid");
        }
        else
        {
            if(get(loc) != null)   
            {
                E temp = get(loc);
                occupantArray[loc.getRow()][loc.getCol()] = obj;
                return temp;
            }
            else
            {
                occupantArray[loc.getRow()][loc.getCol()] = obj;
                return null;
            }
        }
    }
    
    /**
     * remove obj on Location "loc" on MyBoundedGrid
     * @param loc the location on MyBoundedGrid from which 
     * obj should be removed
     * @return removed object or null if location 
     * was unoccupied
     */
    public E remove(Location loc)
    {
        if(!isValid(loc))
        {
            throw new RuntimeException("location is in valid");
        }
        else
        {
            if(get(loc) != null)
            {
                E temp = get(loc);
                occupantArray[loc.getRow()][loc.getCol()] = null;
                return temp;
            }
            else
            {
                return null;
            }
        }
    }
    
    /**
     * gives object at Location "loc" on MyBoundedGrid
     * @param loc location whose object method will find
     * @return object at Location "loc" on MyBoundedGrid 
     * or null if location is unoccupied
     */
    public E get(Location loc)
    {
        return (E)(occupantArray[loc.getRow()][loc.getCol()]);
    }
    
    /**
     * gives list of locations that are occupied on MyBoundedGrid
     * @return list of occupied locations in MyBoundedGrid
     */
    public ArrayList<Location> getOccupiedLocations()
    {
        ArrayList<Location> occupiedLocations = new ArrayList<>();
        for(int r = 0; r < numRows; r++)
        {
            for(int c = 0; c < numCols; c++)
            {
                Location l = new Location(r, c);
                if(get(l) != null)
                {
                    occupiedLocations.add(l);
                }
            }
        }
        return occupiedLocations;
    }
}
