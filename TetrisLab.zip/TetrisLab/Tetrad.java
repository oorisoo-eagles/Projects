import java.awt.Color;
import java.util.*;
import java.util.concurrent.Semaphore;
/**
 * Creates Tetrad blocks for the Tetris game to use
 *
 * @author Risa Chokhawala
 * @version April 6, 2024
 */
public class Tetrad
{
    private Block[] blocks;
    private MyBoundedGrid<Block> grid;
    private int type;
    private static final int I = 1;
    private static final int T = 2;
    private static final int O = 3;
    private static final int L = 4;
    private static final int J = 5;
    private static final int S = 6;
    private static final int Z = 7;
    private Color color;
    private Semaphore lock;
    
    /**
     * Creates a Tetrad object
     * @param gr grid where Tetrad object will be held
     */
    public Tetrad(MyBoundedGrid<Block> gr)
    {
        lock = new Semaphore(1, true);
        grid = gr;
        blocks = new Block[4];
        for (int i = 0; i < blocks.length; i++)
        {
            blocks[i] = new Block();
        }
        type = (int)(Math.random()*7)+1;
        setColor();
        for(int i = 0; i < blocks.length; i++)
        {
            blocks[i].setColor(color);
        }
        addToLocations(gr, setLocs());
    }

    /**
     * sets all blocks in Tetrad to correct color depending on the type of Tetrad
     */
    public void setColor()
    {
        if(type == I)
        {
            color = Color.RED;
        }
        else if(type == T)
        {
            color = Color.GRAY;
        }
        else if(type == O)
        {
            color = Color.CYAN;
        }
        else if(type == L)
        {
            color = Color.YELLOW;
        }
        else if(type == J)
        {
            color = Color.MAGENTA;
        }
        else if(type == S)
        {
            color = Color.BLUE;
        }
        else
        {
            color = Color.GREEN;
        }
    }
    
    /**
     * calculates locs where tetrad's blocks should start based on type of tetrad
     * @return array of locs where tetrad's blocks should start
     */
    private Location[] setLocs()
    {
        Location[] newLoc = new Location[4];
        if (type == I)
        {
            newLoc[0] = new Location(2, 4);
            newLoc[1] = new Location(1, 4);
            newLoc[2] = new Location(0, 4);
            newLoc[3] = new Location(3, 4);
        }
        else if (type == O)
        {
            newLoc[0] = new Location(0, 5);
            newLoc[1] = new Location(0, 4);
            newLoc[2] = new Location(1, 4);
            newLoc[3] = new Location(1, 5);
        }
        else if (type == T)
        {
            newLoc[0] = new Location(0, 4);
            newLoc[1] = new Location(0, 3);
            newLoc[2] = new Location(1, 4);
            newLoc[3] = new Location(0, 5); 
        }
        else if (type == L)
        {
            newLoc[0] = new Location(1, 4);
            newLoc[1] = new Location(0, 4);
            newLoc[2] = new Location(2, 4);
            newLoc[3] = new Location(2, 5); 
        }
        else if (type == J)
        {
            newLoc[0] = new Location(1, 5);
            newLoc[1] = new Location(0, 5);
            newLoc[2] = new Location(2, 5);
            newLoc[3] = new Location(2, 4); 
        }
        else if (type == S) //S
        {
            newLoc[0] = new Location(0, 4);
            newLoc[1] = new Location(0, 5);
            newLoc[2] = new Location(1, 4);
            newLoc[3] = new Location(1, 3); 
        }
        else if (type == Z)
        {
            newLoc[0] = new Location(0, 5);
            newLoc[1] = new Location(0, 4);
            newLoc[2] = new Location(1, 5);
            newLoc[3] = new Location(1, 6); 
        }
        return newLoc;
    }
    /**
     * adds blocks to the Locations in locs array on the grid
     * @param gr grid to add blocks to
     * @param locs array of Locations where you want to add blocks
     * precondition:  blocks are not in any grid;
     *                locs.length = 4;
     * postcondition: The locations of blocks match locs 
     *                and blocks have been put in the grid
     */
    private void addToLocations(MyBoundedGrid<Block> gr, Location[] locs)
    {
        for(int i = 0; i < blocks.length; i++)
        {
            blocks[i].putSelfInGrid(gr, locs[i]);
        }
    }
 
    /**
     * removes blocks from grid and returns an array of old locations of blocks
     * @return array of old locations of blocks
     * precondition: Blocks are in the grid.
     * postcondition: Returns old locations of blocks; 
     *                blocks have been removed from grid. 
     */
    private Location[] removeBlocks()
    {
        Location[] oldLocs = new Location[4];
        for(int i = 0; i < blocks.length; i++)
        {
            Location oldLoc = blocks[i].getLocation();
            blocks[i].removeSelfFromGrid();
            oldLocs[i] = oldLoc;
        }
        return oldLocs;
    }
    
    /**
     * checks if all Locations in locs is valid and empty in grid
     * @param gr grid where we are looking for locs
     * @param locs array of locs we are checking
     * @return true if each of locs is valid and empty in grid
     * postcondition: Returns true if each of locs is 
     *                valid and empty in grid; 
     *                false otherwise. 
     */
    private boolean areEmpty(MyBoundedGrid<Block> gr, Location[] locs) 
    {
        for(int i = 0; i < locs.length; i++)
        {
            if(!(gr.isValid(locs[i]) && gr.get(locs[i]) == null))
            {
                return false;
            }
        }
        return true;
    }
    
    /**
     * trys to move tetrad deltaRow rows down and deltaCol columns down if it is valid
     * @param deltaRow number of rows down to move tetrad
     * @param deltaCol number of cols right to move tetrad
     * @return true if translation is valid otherwise false
     * postcondition: Attempts to move this tetrad deltaRow 
     *                rows down and deltaCol columns to the 
     *                right, if those positions are valid
     *                and empty; returns true if successful 
     *                and false otherwise. 
     */
    public boolean translate(int deltaRow, int deltaCol)
    {
        try
        {
            lock.acquire();
            Location[] oldLocs = removeBlocks();
            Location[] newLocs = new Location[4];
            for(int i = 0; i < oldLocs.length; i++)
            {
                newLocs[i] = new Location(oldLocs[i].getRow() + deltaRow,
                oldLocs[i].getCol() + deltaCol);
            }
            if(areEmpty(grid, newLocs))
            {
                addToLocations(grid, newLocs);
                return true;
            }
            else
            {
                addToLocations(grid, oldLocs);
                return false;
            }
        }catch (InterruptedException e)
        {
            //did not modify the tetrad
            return false;
        }finally
        {
            lock.release(); 
        }
    }
    
    /**
     * rotates tetrad 90 degrees clockwise if it is valid
     * @return true if rotation is valid or false otherwise
     * postcondition:  Attempts to rotate this tetrad 
     *                 clockwise by 90 degrees about its 
     *                 center, if the necessary positions 
     *                 are empty; returns true if successful 
     *                 and false otherwise. 
     */
    public boolean rotate()
    {
        try
        {
            lock.acquire();
            if(type == O)
            {
                return false;
            }
            Location[] oldLocs = removeBlocks();
            Location[] newLocs = new Location[4];
            int rowCenter = oldLocs[0].getRow();
            int colCenter = oldLocs[0].getCol();
            for(int i = 0; i < oldLocs.length; i++)
            {
                int newRow = rowCenter - colCenter + oldLocs[i].getCol();
                int newCol = rowCenter + colCenter - oldLocs[i].getRow();
                newLocs[i] = new Location(newRow, newCol);
            }
            if(areEmpty(grid, newLocs))
            {
                addToLocations(grid, newLocs);
                return true;
            }
            else
            {
                addToLocations(grid, oldLocs);
                return false;
            }
        }catch (InterruptedException e)
        {
            //did not modify the tetrad
            return false;
        }finally
        {
            lock.release(); 
        }
    }
    
}
