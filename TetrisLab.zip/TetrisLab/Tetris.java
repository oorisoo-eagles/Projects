/**
 * creates a Tetris game for user to play
 *
 * @author Risa Chokhawala
 * @version April 6, 2024
 */
public class Tetris implements ArrowListener
{
    private MyBoundedGrid<Block> grid;
    private BlockDisplay display; 
    private Tetrad activeTetrad;
    
    /**
     * creates and starts a Tetris game
     * @param args command-line arguments
     */
    public static void main(String[] args)
    {
        Tetris game = new Tetris();
        game.play();
    }
    
    /**
     * creates a Tetris object
     */
    public Tetris()
    {
        grid = new MyBoundedGrid<>(20, 10);
        display = new BlockDisplay(grid);
        display.setArrowListener(this);
        display.setTitle("Tetris");
        display.showBlocks();
        activeTetrad = new Tetrad(grid);
    }
    
    /**
     * starts a Tetris game
     */
    public void play()
    {
        while(true)
        {
            try
            {
                //Pause for 1000 milliseconds.
                Thread.sleep(1000);
                if(!activeTetrad.translate(1, 0))
                {
                    clearCompletedRows();
                    activeTetrad = new Tetrad(grid);
                }
                display.showBlocks();
            }catch(InterruptedException e)
            {
                //ignore
            } 
        }
    }
    
    /**
     * checks if every cell in row is occupied on grid
     * @param row row which we are checking is occupied
     * @return true if every cell is occupied in row
     * precondition: 0 <= row < number of rows
     * postcondition: Returns true if every cell in the 
     *                given row is occupied; 
     *                returns false otherwise. 
     */
    private boolean isCompletedRow(int row) 
    {
        int numCols = grid.getNumCols();
        for(int i = 0; i < numCols; i++)
        {
            if(grid.get(new Location(row, i)) == null)
            {
                return false;
            }
        }
        return true;
    }
    
    /**
     * clears all blocks in row on grid and moves all blocks in above rows down 
     * @param row row whose blocks we want to clear
     * precondition: 0 <= row < number of rows; 
     *               given row is full of blocks 
     * postcondition: Every block in the given row has been 
     *                removed, and every block above row 
     *                has been moved down one row. 
     */
    private void clearRow(int row)
    {
        int numCols = grid.getNumCols();
        for(int i = 0; i < numCols; i++)
        {
            grid.get(new Location(row, i)).removeSelfFromGrid();
        }
        for(int i = row - 1; i > 0; i--)
        {
            for(int j = 0; j < numCols; j++)
            {
                if(grid.get(new Location (i, j)) != null)
                {
                    grid.get(new Location (i, j)).moveTo(new Location (i+1, j));
                }
            }
        }
    }
    
    /**
     * clears completed rows on grid
     * postcondition: all completed rows have been clear
     */
    private void clearCompletedRows()
    {
        int numRows = grid.getNumRows();
        for(int i = 0; i < numRows; i++)
        {
            if(isCompletedRow(i))
            {
                clearRow(i);
            }
        }
    }
    
    /**
     * moves activeTetrad up when up key is pressed
     */
    public void upPressed()
    {
        if(activeTetrad != null)
        {
            activeTetrad.rotate();
            display.showBlocks();
        }
    }
    
    /**
     * moves activeTetrad down when down key is pressed
     */
    public void downPressed()
    {
        if(activeTetrad != null)
        {
            activeTetrad.translate(1, 0);
            display.showBlocks();
        }
    }
    
    /**
     * moves activeTetrad left when left key is pressed
     */
    public void leftPressed()
    {
        if(activeTetrad != null)
        {
            activeTetrad.translate(0, -1);
            display.showBlocks();
        }
    }
    
    /**
     * moves activeTetrad right when right key is pressed
     */
    public void rightPressed()
    {
        if(activeTetrad != null)
        {
            activeTetrad.translate(0, 1);
            display.showBlocks();
        }
    }
}
