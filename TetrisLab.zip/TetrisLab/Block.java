import java.awt.Color;
/**
* class BLock encapsulates a Block abstraction which can be placed into a Gridworld style grid
* 
* @author Risa Chokhawala
* @version March 25, 2024
*/
public class Block
{
    private MyBoundedGrid<Block> grid;
    private Location location;
    private Color color;
    /**
    * constructs a blue block, because blue is the greatest color ever!
    */
    public Block()
    {
        color = Color.BLUE;
        grid = null;
        location = null;
    }
    /**
    * retrieves color of Block
    * @return color of Block
    */
    public Color getColor()
    {
        return color;
    }
    /**
    * updates color of Block to newColor
    * @param newColor the color which color of Block will be changed to
    */
    public void setColor(Color newColor)
    {
        color = newColor;
    }
    
    /**
    * retrieves grid where Block is located
    * @return grid of Block or null if Block is not contained in a grid
    */
    public MyBoundedGrid<Block> getGrid()
    {
        return grid;
    }   
    
    /**
    * retrieves location on grid where Block is located
    * @return location of Block or null if Block is not contained in agrid
    */
    public Location getLocation()
    {
        return location;
    }
    
    /**
     * updates grid of Block to a new grid gr
     * @param gr new grid 
     */
    public void setGrid(MyBoundedGrid<Block> gr)
    {
        grid = gr;
    }
    
    /**
     * updates location of Block to a new location loc
     * @param loc new location 
     */
    public void setLocation(Location loc)
    {
        location = loc;
    }
    
    /**
    * removes Block from grid
    */
    public void removeSelfFromGrid()
    {
        grid.remove(location);
        grid = null;
        location = null;
    }
    
    /**
    * puts this Block into Location "loc" of grid "gr" if there is another 
    * Block already there at Location "loc" it is removed from the grid "gr"
    * @param gr Grid where Block will be placed
    * @param loc Location where Block will be placed
    */
    public void putSelfInGrid(MyBoundedGrid<Block> gr, Location loc)
    {
        if(gr.get(loc) != null)
        {
            Block previous = (Block)(gr.get(loc));
            previous.removeSelfFromGrid();
        }
        gr.put(loc, this);
        grid = gr;
        location = loc;
    }

    /**
    * moves Block to newLocation if there is another Block at newLocation 
    * it is removed
    * @param newLocation location which Block will be moved to
    */
    public void moveTo(Location newLocation)
    {
        MyBoundedGrid<Block> gr = grid;
        removeSelfFromGrid();
        putSelfInGrid(gr, newLocation);
    }

    /**
    * returns a string with the location and color of this block
    * @return string that represents Block object
    */
    public String toString()
    {
        return "Block[location=" + location + ",color=" + color + "]";
    }
}