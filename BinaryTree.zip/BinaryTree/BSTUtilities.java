/**
 * A collection of static methods for operating on binary search trees
 * 
 * @author Amiya Chokhawala  
 * @version December 31, 2021 
 *
 */
public abstract class BSTUtilities  <E extends Comparable<E>> 
{
    //precondition:  t is a binary search tree in ascending order
    //postcondition: returns true if t contains the value x;
    //               otherwise, returns false
    public static boolean contains(TreeNode t, Comparable x, TreeDisplay display)
    {
        if( t == null )
            return false;

        int compareResult = x.compareTo(t.getValue());

        if( compareResult < 0 )
            return contains(t.getLeft(), x, display);
        else if( compareResult > 0 )
            return contains(t.getRight(), x, display);
        else
            return true;
    }

    //precondition:  t is a binary search tree in ascending order
    //postcondition: if t is empty, returns a new tree containing x;
    //               otherwise, returns t, with x having been inserted
    //               at the appropriate position to maintain the binary
    //               search tree property; x is ignored if it is a
    //               duplicate of an element already in t; only one new
    //               TreeNode is created in the course of the traversal
    public static TreeNode insert(TreeNode t, Comparable x, TreeDisplay display)
    {
       if(!contains(t, x, display))
        {
            if(t == null)
                return new TreeNode(x);
            display.visit(t);
            
            if(x.compareTo(t.getValue()) < 0)
                t.setLeft(insert(t.getLeft(), x, display));
            
            if(x.compareTo(t.getValue()) > 0)
                t.setRight(insert(t.getRight(), x, display));
        }
        return t;
    }

    //precondition:  t is a binary search tree in ascending order
    //postcondition: returns a pointer to a binary search tree,
    //               in which the value at node t has been deleted
    //               (and no new TreeNodes have been created)
    private static TreeNode deleteNode(TreeNode t, TreeDisplay display)
    {        
        //the tree is a leaf node
        if (t.getLeft() == null && t.getRight() == null)
        {
            return null; 
        }
        // one child 
        else if (t.getLeft() == null) 
        {
            TreeNode temp = t; 
            t = t.getRight();
            return t; 
        }
        else if (t.getRight() == null) 
        {
            TreeNode temp = t; 
            t = t.getLeft();
            return t; 
        }
        else 
        {
            // two children 
            // find the successor 
            Object successor = TreeUtil.leftmost(t.getRight()); 
            // replace the value 
            t.setValue(successor); 
            // set the subtree with the sucessor removed 
            TreeNode x = delete(t.getRight(), (Comparable) successor, display);
            t.setRight(x); 
            return t; 
        }
    }

    //precondition:  t is a binary search tree in ascending order
    //postcondition: returns a pointer to a binary search tree,
                  //in which the value x has been deleted (if present)
                  //(and no new TreeNodes have been created)
    public static TreeNode delete(TreeNode t, Comparable x, TreeDisplay display)
    {
        if (t == null) 
        {
            return t;
        }
        
        int compare = x.compareTo(t.getValue()); 
        
        if (compare < 0)
        {
            TreeNode d = delete(t.getLeft(), x, display);
            t.setLeft(d);
        }
        else if (compare > 0)
        {
            t.setRight((delete(t.getRight(), x, display)));
        }
        else
        t = deleteNode(t, display);
        return t;        
    }
}
