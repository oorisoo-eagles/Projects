import java.util.*;

/**
 * Write a description of class Tester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tester
{
    public static void main(String[] args)
    {
        TreeSet<Integer> t = new TreeSet<Integer>();
        System.out.println(t.size()); 
        t.add(1); 
        t.add(2); 
        t.add(3); 
        t.add(4); 
        t.add(5); 
    }
}
