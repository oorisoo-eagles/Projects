import java.util.Iterator;
import java.util.*;

/**
 * All values in a MyTreeSet object are unique.
 * The MyTreeSet uses a binary search tree add and remove elements. 
 * 
 * @author Amiya Chokhawala
 * @version January 12, 2022
 * 
 */
public class MyTreeSet<E>
{
    private TreeNode root;
    private int size;
    private TreeDisplay display;

    /**
     * Constructor for a MyTreeSet object
     */
    public MyTreeSet()
    {
        root = null;
        size = 0;
        display = new TreeDisplay();

        //wait 1 millisecond when visiting a node
        display.setDelay(1);
    }

    /**
     * Returns the size of the MyTreeSet
     * @return  the number of elements in the object
     */
    public int size()
    {
        return size;
    }

    /**
     * Checks if the object is in the MyTreeSet object
     * @param   obj the object that is being check for 
     * @return  true if obj is there; 
     *          otherwise, false
     */
    public boolean contains(Object obj)
    {
        return BSTUtilities.contains(root, (Comparable) obj, display);
    }

    /**
     * if obj is not present in this set, adds obj 
     * 
     * @param obj the object that is being added
     * @return true if obj is not inthe set;
     * otherwise returns false
     */
    public boolean add(E obj)
    {
        boolean x = contains(obj);
        
        if (!x)
        {
            size++;
        }
            
        root = BSTUtilities.insert(root, (Comparable) obj, display);
        return !x;
    }

    /**
     * if obj is present in this set, removes obj 
     * 
     * @param obj the object that is being removed
     * @return true if obj is in the set;
     * otherwise returns false
     */
    public boolean remove(Object obj)
    {
        boolean x  = contains(obj);
        if (x){
            size--;
        }
        root = BSTUtilities.delete(root, (Comparable) obj, display);
        return x;
    }
    

    // iterator class for BinaryTree
    public Iterator iterator() {
        return new Iterator() {
            public boolean hasNext() {
                return (root.getLeft() != null) && (root.getRight() != null);
            }

            public TreeNode next() {
                if (root.getLeft() != null) {
                    TreeNode node = root.getLeft();
                    display.visit(node);
                    return node;
                } 
                if (root.getRight() != null) { 
                    TreeNode node = root.getRight();
                    display.visit(node);
                    return node;
                }
                return root;
            }

            public void remove() {
                // Not allowing;
            }
        };
    }

    /**
     * Returns the elements of the MyTreeSet object in the form of a string
     * @return  the string of the elements of the MyTreeSet object 
     */
    public String toString()
    {
        return toString(root);
    }

    /**
     * Displays the value of a TreeNode t and its sub-TreeNodes in a string

     * @param t 
     * @return the value of a TreeNode t and its sub-TreeNodes
     */
    private String toString(TreeNode t)
    {
        if (t == null)
            return " ";
        return toString(t.getLeft()) + t.getValue() + toString(t.getRight());
    }
}