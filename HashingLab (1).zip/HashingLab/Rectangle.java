/**
 * Rectangle object that has width, length properties of a rectangle
 * @author Risa Chokhawala
 * @version Jan 26, 2024
 * @param <K>   the type of key
 * @param <V>   the type of value
 */
public class Rectangle
{
    private int length;
    private int width;

    /**
     * Creates a rectangle object with length and width properties
     *
     * @param len the length of the rectangle
     * @param w the width of the rectangle
    */
    public Rectangle(int len, int w)
    {
        length = len;
        width = w;
    }
    /**
     * get length of rectangle
     * @return length of rectangle
    */
    public int getLength()
    {
        return length;
    }

    /**
     * get width of rectangle
     * @return width of rectangle
    */
    public int getWidth()
    {
        return width;
    }
    
    /**
     * checks if two rectangle objects are equal
     * @param obj - the rectangle that will be compared with
     * @return true if both rectangles have equal width and length 
     * otherwise false
    */
    public boolean equals(Object obj)
    {
        if((((Rectangle)(obj)).getLength() == length) && (((Rectangle)(obj)).getWidth() == width))
        {
            return true;
        }
        return false;
    }

    /**
     * gives hashCode of this Rectangle object
     * @return hashCode of this rectangle 
     * (NOTE: rectangles that are equal should return the same hashCode)
    */
    public int hashCode()
    {
        return (1022*length + 1022*width);
    }
    
    /**
     * represents Rectangle object as a String 
     * @return a String that has the length and width of this Rectangle object
     * and represents this Rectangle object
    */
    public String toString()
    {
        return length + "x" + width;
    }
}