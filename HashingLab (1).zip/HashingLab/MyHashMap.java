import java.util.*;
/**
 * MyHashMap acts like a map.
 * 
 * @author Risa Chokhawala
 * @version Jan 26, 2024
 * @param <K>   the type of key
 * @param <V>   the type of value
 */
public class MyHashMap<K, V> implements Map<K, V>
{
    private static final int NUM_BUCKETS = 5;
    private LinkedList<MapEntry<K, V>>[] buckets;
    private int size;

    /**
     * a constructor
     */
    public MyHashMap()
    {
        buckets = new LinkedList[NUM_BUCKETS];
        for (int i = 0; i < NUM_BUCKETS; i++)
        {
            buckets[i] = new LinkedList<>();
        }
        size = 0;
    }
    
    /**
     * finds a bucket index for a given object
     * @param obj
     *            the object to find the bucket index for
     * @return the correct bucket index for that object
     */
    private int toBucketIndex(Object obj)
    {
        return Math.abs(obj.hashCode()) % NUM_BUCKETS;
    }

    /**
     * gives number of elements in HashMap
     * @return size of HashMap
     */
    public int size()
    {
        return size;
    }

    /**
     * checks if HashMap is 0
     * @return if size of HashMap is 0 returns true otherwise returns false
     */
    public boolean isEmpty()
    {
        return size == 0;
    }

    @Override
    /**
     * checks if HashMap contains key given
     * @param key - the key you are checking that the HashMap contains
     * @return true if HashMap contains key false otherwise
     */
    public boolean containsKey(Object key)
    {
        Set<K> keys = this.keySet();
        for(K k: keys)
        {
            if(k.equals(key))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * checks if hashMap contains value given
     * @param value - the value you are checking that the HashMap contains
     * @return true if HashMap contains value false otherwise
     */
    public boolean containsValue(Object value)
    {
        Collection<V> valuesOfMap = this.values();
        for(V v: valuesOfMap)
        {
            if(v.equals(value))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * gets value mapped to a given key in the HashMap
     * @param key - the key whos value you are trying to obtain
     * @return value of given key 
     */
    public V get(Object key)
    {
        if(!this.containsKey(key))
        {
            return null;
        }
        for ( int j = 0; j < buckets.length; j++)
        {
            LinkedList<MapEntry<K, V>> bucket = buckets[j];
            for(int i = 0; i < bucket.size(); i++)
            {
                if(bucket.get(i).getKey().equals(key))
                {
                    return bucket.get(i).getValue();
                }
            }
        }
        return null;
    }
    
    /**
     * adds a key-value pair to the HashMap 
     * or updates value of a key already in the HashMap
     * @param key - the key that will be added to the HashMap
     * or the key that whose value will be updated
     * @param value - the value that will be mapped to the key 
     * @return the old value if the key is already in the HashMap
     * or null if the key is new to the HashMap
     */
    public V put(K key, V value)
    {
        if(this.containsKey(key))
        {
            Set<java.util.Map.Entry<K, V>> pairs = entrySet();
            for(java.util.Map.Entry<K, V> pair: pairs)
            {
                if(pair.getKey().equals(key))
                {
                    V ogValue = pair.getValue();
                    pair.setValue(value);
                    return ogValue;
                }
            }
        }
        int index = this.toBucketIndex(key);
        buckets[index].add(new MapEntry<>(key, value));  
        size++;
        return null;
    }
    
    /**
     * removes a key-value pair from the hashMap
     * @param key - the key that will be deleted
     * @return old value of the key that was deleted
     */    
    public V remove(Object key)
    {
        if(!containsKey(key))
        {
            return null;
        }
        int indexOfBucket = toBucketIndex(key);
        int indexOfKey = 0;
        for(int i = 0; i < buckets[indexOfBucket].size(); i++)
        {
            if(buckets[indexOfBucket].get(i).equals(key))
            {
                indexOfKey = i;
            }
        }
        V originalValue = buckets[indexOfBucket].get(indexOfKey).getValue();
        buckets[indexOfBucket].remove(indexOfKey);
        size--;
        return originalValue;
    }

    /**
     * puts all values from another Map object into this HashMap
     * @param m - Map that will be added to this HashMap
     */  
    public void putAll(Map<? extends K, ? extends V> m)
    {
        for (K key : m.keySet())
        {
            put(key, m.get(key));
        }
    }

    /**
     * clears all key-value pairs from the hashMap
     */  
    public void clear()
    {
        for (int i = 0; i < NUM_BUCKETS; i++)
        {
            buckets[i] = null;
        }
    }

    /**
     * gives a HashSet of all the keys in this HashMap
     * @return a Set of keys of this HashMap
     */  
    public Set<K> keySet()
    {
        Set<K> keys = new HashSet<>();
        for ( int j = 0; j < buckets.length; j++)
        {
            LinkedList<MapEntry<K, V>> bucket = buckets[j];
            if(bucket != null)
            {
                for(int i = 0; i < bucket.size(); i++)
                {
                    keys.add(bucket.get(i).getKey());
                }
            }
        }
        return keys;
    }

    /**
     * gives a Collection object of the values in this HashMap
     * @return a Collection of values of this HashMap
     */  
    public Collection<V> values()
    {
        Collection<V> valuesOfMap = new ArrayList<>();
        for ( int j = 0; j < buckets.length; j++)
        {
            LinkedList<MapEntry<K, V>> bucket = buckets[j];
            if(bucket != null)
            {
                for(int i = 0; i < bucket.size(); i++)
                {
                    valuesOfMap.add(bucket.get(i).getValue());
                }
            }
        }
        return valuesOfMap;
    }
    
    /**
     * gives a HashSet of all the MapEntries in this HashMap
     * @return all the key-value pairs or MapEntries in this HashMap
     */  
    @Override
    public Set<java.util.Map.Entry<K, V>> entrySet()
    {
        Set<java.util.Map.Entry<K, V>> pairs = new HashSet<>();
        for ( int j = 0; j < buckets.length; j++)
        {
            LinkedList<MapEntry<K, V>> bucket = buckets[j];
            for(int i = 0; i < bucket.size(); i++)
            {
                pairs.add(bucket.get(i));
            }
        }
        return pairs;
    }
}
