import java.util.*;
/**
 * MyHashSet acts like a set
 * 
 * @author Risa Chokhawala
 * @version Jan 26, 2024
 * @param <E> the type of element contained
 */

public class MyHashSet<E> implements Iterable 
{
    private static final int NUM_BUCKETS = 5;
    private LinkedList<E>[] buckets;
    private int size;
    
    /**
     * a constructor
     */
    public MyHashSet()
    {
        buckets = new LinkedList[NUM_BUCKETS];
        size = 0;
        for(int i = 0; i < buckets.length; i++)
        {
            buckets[i] = new LinkedList<>();
        }
    }

    //returns the index of the bucket where obj might be found
    private int toBucketIndex(Object obj)
    {
        return (Math.abs(obj.hashCode())) %  (NUM_BUCKETS);
    }

    /**
     * gives number of elements in HashSet
     * @return size of HashSet
     */
    public int size()
    {
        return size;
    }

    /**
     * checks if HashSet contains object given
     * @param obj - the key object are checking that the HashSet contains
     * @return true if HashSet contains obj false otherwise
     */
    public boolean contains(Object obj)
    {
        LinkedList<E> list = buckets[toBucketIndex(obj)];
        for(E element: list)
        {
            if(element.equals(obj))
            {
                return true;
            }
        }
        return false;
    }

    // if obj is not present in this set, adds obj and
    // returns true; otherwise returns false
    public boolean add(E obj)
    {
        if(contains(obj))
        {
            return false;
        }
        buckets[toBucketIndex(obj)].add(obj);
        size ++;
        return true;
    }

    // if obj is present in this set, removes obj and
    // returns true; otherwise returns false
    public boolean remove(Object obj)
    {
        if(!contains(obj))
        {
            return false;
        }
        int index = toBucketIndex(obj);
        for(int i = 0; i < buckets[index].size(); i++)
        {
            if(buckets[index].get(i).equals(obj))
            {
                buckets[index].remove(i);
            }
        }
        size --;
        return true;
    }

    /**
     * represents set in the format "index of buckets:[elements]"
     * @return a string composed of all of the elements of the set
     * in the format explained above
     */
    public String toString()
    {
        String s = "";
        for (int i = 0; i < buckets.length; i++)
        {
            if (buckets[i].size() > 0)
            {
                s += i + ":" + buckets[i] + " ";
            }
        }
        return s;
    }
  
    /**
     * creates a SetIterator for this HashSet
     * @return the new SetIterator for this HashSet
     */
    public Iterator iterator()
    {
        return new SetIterator();
    }
    
    private class SetIterator implements Iterator<E>
    {
        private int currentIndex;
        private Iterator it;
        private E lastReturnedElement = null;
        /**
         * constructor
         */
        public SetIterator()
        {
            currentIndex = 0;
            it = buckets[currentIndex].iterator(); 
        }
        @Override
        /**
         * checks if SetIterator has a next element 
         * @return true if SetIterator has next element false otherwise
        */
        public boolean hasNext()
        {
            if (it.hasNext())
            {
                return true;
            }
            while(!it.hasNext() && currentIndex < buckets.length)
            {
                currentIndex++;
                if (currentIndex == buckets.length)
                {
                    return false;
                }
                it= buckets[currentIndex].iterator();
            }
            if ( currentIndex >= buckets.length )
            {
                return false;
            }
            return it.hasNext();
        }
        
        /**
         * moves the SetIterator to next element if there is one available 
         * @return the element before the iterator
        */
        @Override
        public E next()
        {
            if(hasNext())
            {
                lastReturnedElement = (E) it.next();
                return lastReturnedElement;
            }
            throw new java.util.NoSuchElementException();
        }
       
        @Override
        /**
         * removes the last returned element by the iterator
        */
        public void remove() 
        {
            if(lastReturnedElement == null)
            {
                System.out.println("remove cannot be called");
                return;
            }
            buckets[toBucketIndex(lastReturnedElement)].remove(lastReturnedElement);
            size--;
            lastReturnedElement = null;
        }
    }
}