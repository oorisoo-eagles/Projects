import java.awt.*;
import java.util.*;
/**
 * make a game Board
 *
 * @author Risa Chokhawala
 * @version April 25, 2024
 */
// Represesents a rectangular game board, containing Piece objects.
public class Board extends BoundedGrid<Piece>
{
    // Constructs a new Board with the given dimensions
    /**
     * Constructs a new Board with the given dimensions
     */
    public Board()
    {
        super(8, 8);
    }

    // Precondition:  move has already been made on the board
    // Postcondition: piece has moved back to its source,
    //                and any captured piece is returned to its location
    /**
     * undoes given move on board
     * @param move to undo
     */
    public void undoMove(Move move)
    {
        Piece piece = move.getPiece();
        Location source = move.getSource();
        Location dest = move.getDestination();
        Piece victim = move.getVictim();

        piece.moveTo(source);

        if (victim != null)
        {
            victim.putSelfInGrid(piece.getBoard(), dest);
        }
    }
    
    /**
     * generates a list of all legal moves for pieces of the given color
     * @param color color of piece whose legal moves we are finding
     * @return an ArrayList of Move objects that represent legal moves
     * for pieces of the given color
     */
    public ArrayList<Move> allMoves(Color color)
    {
        ArrayList<Location> allOccupiedLocs = getOccupiedLocations();
        ArrayList<Move> allLegalMoves = new ArrayList<>();
        for(Location loc: allOccupiedLocs)
        {
            Piece source = (Piece)(get(loc));
            if(source.getColor().equals(color))
            {
                for(Location dest: source.destinations())
                {
                    allLegalMoves.add(new Move(source, dest));
                }
            }
        }
        return allLegalMoves;
    }
    
    /**
     * executes Move on Piece
     * @param move Move to execute 
     */
    public void executeMove(Move move)
    {
        move.getPiece().moveTo(move.getDestination());
    }
}