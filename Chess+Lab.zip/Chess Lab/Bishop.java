import java.awt.Color;
import java.util.*;
/**
 * Creates a Bishop Piece
 *
 * @author Risa Chokhawala
 * @version April 23, 2024
 */
public class Bishop extends Piece
{
    /**
     * constructs a new Bishop Piece with the given attributes.
     * @param col of Bishop
     * @param fileName file name of img used to display Bishop
     */
    public Bishop(Color col, String fileName)
    {
        super(col, fileName, 3);
    }
    
    /**
     * generates list of locations which Bishop can move to
     * @return ArrayList listing locations the Bishop can move to
     */
    public ArrayList<Location> destinations()
    {
        ArrayList validNeighborLocs = new ArrayList<>();
        sweep(validNeighborLocs, Location.NORTHWEST);
        sweep(validNeighborLocs, Location.NORTHEAST);
        sweep(validNeighborLocs, Location.SOUTHWEST);
        sweep(validNeighborLocs, Location.SOUTHEAST);
        return validNeighborLocs;
    }
}
