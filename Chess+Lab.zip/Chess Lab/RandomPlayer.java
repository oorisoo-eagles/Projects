import java.awt.Color;
import java.util.ArrayList;
/**
 * make a RandomPlayer to play the chess game
 *
 * @author Risa Chokhawala
 * @version April 25, 2024
 */
public class RandomPlayer extends Player
{
    /**
     * creates a RandomPlayer for the game
     * @param b Board where RandomPlayer is playing
     * @param n name of RandomPlayer
     * @param c Color of RandomPlayer
     */
    public RandomPlayer(Board b, String n, Color c)
    {
        super(b, n, c);
    }
    
    /**
     * gets RandomPlayer's next move in the game
     * @return Move that represents next move of RandomPlayer
     */
    public Move nextMove()
    {
        ArrayList<Move> allValidMoves = board.allMoves(color);
        return allValidMoves.get((int)(Math.random()*allValidMoves.size()));
    }
}
