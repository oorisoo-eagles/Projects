import java.awt.Color;
import java.util.*;
/**
 * Creates a Queen Piece
 *
 * @author Risa Chokhawala
 * @version April 23, 2024
 */
public class Queen extends Piece
{
    /**
     * constructs a new Bishop Piece with the given attributes.
     * @param col Color of Queen
     * @param fileName file of img to display Queen
     */
    public Queen(Color col, String fileName)
    {
        super(col, fileName, 9);
    }
    
    /**
     * generates list of locations which Queen can move to
     * @return ArrayList listing locations the Queen can move to
     */
    public ArrayList<Location> destinations()
    {
        ArrayList validDests = new ArrayList<>();
        sweep(validDests, Location.NORTH);
        sweep(validDests, Location.SOUTH);
        sweep(validDests, Location.EAST);
        sweep(validDests, Location.WEST);
        sweep(validDests, Location.NORTHWEST);
        sweep(validDests, Location.NORTHEAST);
        sweep(validDests, Location.SOUTHWEST);
        sweep(validDests, Location.SOUTHEAST);
        return validDests;
    }
}
