import java.awt.Color;
import java.util.*;
/**
 * Creates a Chess Game
 *
 * @author Risa Chokhawala
 * @version April 23, 2024
 */
public class Game
{
    /**
     * makes a Chess Game for user to play
     * @param args lines that compiler reads in
     */
    public static void main(String[] args)
    {
        Board board = new Board();
        
        //Kings
        Piece blackKing = new King(Color.BLACK, "black_king.gif");
        blackKing.putSelfInGrid(board, new Location(0, 4));
        Piece whiteKing = new King(Color.WHITE, "white_king.gif");
        whiteKing.putSelfInGrid(board, new Location(7, 4));
        //Rooks
        Piece blackRook1 = new Rook(Color.BLACK, "black_rook.gif");
        Piece blackRook2 = new Rook(Color.BLACK, "black_rook.gif");
        blackRook1.putSelfInGrid(board, new Location(0, 0));
        blackRook2.putSelfInGrid(board, new Location(0, 7));
        Piece whiteRook1 = new Rook(Color.WHITE, "white_rook.gif");
        Piece whiteRook2 = new Rook(Color.WHITE, "white_rook.gif");
        whiteRook1.putSelfInGrid(board, new Location(7, 0));
        whiteRook2.putSelfInGrid(board, new Location(7, 7));
        //Pawns
        Piece[] whitePawns = new Piece[8];
        for (int i=0; i<8; i++)
        {
            whitePawns[i] = new Pawn(Color.WHITE, "white_pawn.gif");
            whitePawns[i].putSelfInGrid(board, new Location(6, i));
        }
        Piece[] blackPawns = new Piece[8];
        for (int i=0; i<8; i++)
        {
            blackPawns[i] = new Pawn(Color.BLACK, "black_pawn.gif");
            blackPawns[i].putSelfInGrid(board, new Location(1, i));
        }
        //Knights
        Piece blackKnight1 = new Knight(Color.BLACK, "black_knight.gif");
        blackKnight1.putSelfInGrid(board, new Location(0, 1));
        Piece blackKnight2 = new Knight(Color.BLACK, "black_knight.gif");
        blackKnight2.putSelfInGrid(board, new Location(0, 6));
        Piece whiteKnight1 = new Knight(Color.WHITE, "white_knight.gif");
        whiteKnight1.putSelfInGrid(board, new Location(7, 1));
        Piece whiteKnight2 = new Knight(Color.WHITE, "white_knight.gif");
        whiteKnight2.putSelfInGrid(board, new Location(7, 6));
        //Bishop
        Piece blackBishop1 = new Bishop(Color.BLACK, "black_bishop.gif");
        blackBishop1.putSelfInGrid(board, new Location(0, 2));
        Piece blackBishop2 = new Bishop(Color.BLACK, "black_bishop.gif");
        blackBishop2.putSelfInGrid(board, new Location(0, 5));
        Piece whiteBishop1 = new Bishop(Color.WHITE, "white_bishop.gif");
        whiteBishop1.putSelfInGrid(board, new Location(7, 2));
        Piece whiteBishop2 = new Bishop(Color.WHITE, "white_bishop.gif");
        whiteBishop2.putSelfInGrid(board, new Location(7, 5));
        //Queen
        Piece blackQueen = new Queen(Color.BLACK, "black_queen.gif");
        blackQueen.putSelfInGrid(board, new Location(0, 3));
        Piece whiteQueen = new Queen(Color.WHITE, "white_queen.gif");
        whiteQueen.putSelfInGrid(board, new Location(7, 3));
        
        BoardDisplay display = new BoardDisplay(board);
        HumanPlayer player1 = new HumanPlayer(board, "Bob", Color.BLACK, display);
        SmartPlayer player2 = new SmartPlayer(board, "Sara", Color.WHITE);
        play(board, display, player2, player1);
    }
    
    /**
     * makes Player execute its nextMove, leaving 
     * the move's source and destination highlighted
     * @param board board which player is in
     * @param display display of board 
     * @param player player whose turn we want to execute
     */
    private static void nextTurn(Board board, BoardDisplay display, Player player)
    {
        display.setTitle(player.getName());
        Move nextMove = player.nextMove();
        board.executeMove(nextMove);
        display.clearColors();
        display.setColor(nextMove.getSource(), Color.YELLOW);
        display.setColor(nextMove.getDestination(), Color.GREEN);
        try
        {
            Thread.sleep(500);
        } catch(InterruptedException e)
        {
        }
    }
    
    /**
     * starts chess Game
     * @param board for game
     * @param display board display for game
     * @param white white player for game
     * @param black black player for game
     */
    public static void play(Board board, BoardDisplay display, 
        Player white, Player black)
    {
        while(true)
        {
            nextTurn(board, display, white);
            nextTurn(board, display, black);
        }
    }
}
