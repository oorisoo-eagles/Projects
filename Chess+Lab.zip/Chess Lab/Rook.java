import java.awt.Color;
import java.util.*;
/**
 * Creates a Rook Piece
 *
 * @author Risa Chokhawala
 * @version April 23, 2024
 */
public class Rook extends Piece
{
    /**
     * constructs a new Rook Piece with the given attributes.
     * @param col of Rook
     * @param fileName file name of img used to display Rook
     */
    public Rook(Color col, String fileName)
    {
        super(col, fileName, 5);
    }
    
    /**
     * generates list of locations which Rook can move to
     * @return ArrayList listing locations the Rook can move to
     */
    public ArrayList<Location> destinations()
    {
        ArrayList validNeighborLocs = new ArrayList<>();
        sweep(validNeighborLocs, Location.NORTH);
        sweep(validNeighborLocs, Location.SOUTH);
        sweep(validNeighborLocs, Location.EAST);
        sweep(validNeighborLocs, Location.WEST);
        return validNeighborLocs;
    }
}
