import java.awt.Color;
import java.util.ArrayList;
/**
 * make a SmartPlayer to play the chess game
 *
 * @author Risa Chokhawala
 * @version April 25, 2024
 */
public class SmartPlayer extends Player
{
    /**
     * creates a SmartPlayer for the game
     * @param b Board where SmartPlayer is playing
     * @param n name of SmartPlayer
     * @param c Color of SmartPlayer
     */
    public SmartPlayer(Board b, String n, Color c)
    {
        super(b, n, c);
    }
    
    /**
     * calculates score of player at current moment 
     * to determine how good board is for SmartPlayer
     * @return score of player at current board arrangement
     */
    public int score()
    {
        int sum = 0;
        for (int row=0; row<getBoard().getNumRows(); row++)
        {
            for (int col=0; col<getBoard().getNumCols(); col++)
            {
                Piece piece = getBoard().get(new Location(row, col));
                if (piece!=null)
                {
                    if (piece.getColor().equals(getColor()))
                    {
                        sum += piece.getValue();
                    }
                    else
                    {
                        sum -= piece.getValue();
                    }
                }
            }
        }
        return sum;
    }
    
    /**
     * gets SmartPlayer's next move in the game
     * @return Move that represents next move of SmartPlayer
     */
    public Move nextMove()
    {
        ArrayList<Move> allValidMoves = getBoard().allMoves(getColor());
        Move maximizingMove = null;
        int maxScore = -1000;
        for(Move m: allValidMoves)
        {
            getBoard().executeMove(m);
            if(valueOfMeanestResponse(2) > maxScore)
            {
                maxScore = score();
                maximizingMove = m;
            }
            getBoard().undoMove(m);
        }
        return maximizingMove;
    }
    
    /**
     * finds value of the meanest response other player can take
     * @param numMoves how many moves took look ahead
     * @return value of meanest response from other player
     */
    private int valueOfMeanestResponse(int numMoves)
    {
        ArrayList<Move> allValidMoves;
        int minScore = 0;
        if(color.equals(Color.BLACK))
        {
            allValidMoves = getBoard().allMoves(Color.WHITE);
        }
        else
        {
            allValidMoves = getBoard().allMoves(Color.BLACK);
        }
        if(numMoves == 0)
        {
            return score();
        }
        for(Move m: allValidMoves)
        {
            getBoard().executeMove(m);
            int testScore = valueOfBestMove(numMoves - 1);
            if( testScore < minScore)
            {
                minScore = testScore;
            }
            getBoard().undoMove(m);
        }
        return minScore;
    }
   
    /**
     * finds value of the best move SmartPlayer can take
     * @param numMoves how many moves took look ahead
     * @return value of best move from SmartPlayer
     */
    private int valueOfBestMove(int numMoves)
    {
        if(numMoves == 0)
        {
            return score();
        }
        ArrayList<Move> allValidMoves = getBoard().allMoves(getColor());
        int maxScore = -1000;
        for(Move m: allValidMoves)
        {
            getBoard().executeMove(m);
            int testScore = valueOfMeanestResponse(numMoves - 1);
            if(testScore > maxScore)
            {
                maxScore = testScore;
            }
            getBoard().undoMove(m);
        }
        return maxScore;
    }
}
