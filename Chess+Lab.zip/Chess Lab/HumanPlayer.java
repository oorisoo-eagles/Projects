import java.awt.Color;
import java.util.ArrayList;
/**
 * make a HumanPlayer to play the chess game
 *
 * @author Risa Chokhawala
 * @version April 25, 2024
 */
public class HumanPlayer extends Player
{
    BoardDisplay display;
    
    /**
     * creates a HumanPlayer for the game
     * @param b Board where HumanPlayer is playing
     * @param n name of HumanPlayer
     * @param c Color of HumanPlayer
     * @param d BoardDisplay of HumanPlayer
     */
    public HumanPlayer(Board b, String n, Color c, BoardDisplay d)
    {
        super(b, n, c);
        display = d;
    }
 
    /**
     * gets HumanPlayer's next move in the game
     * @return Move that represents next move of HumanPlayer
     */
    public Move nextMove()
    {
        boolean legalMoveFound = false;
        Move possibleMove = null;
        while(!legalMoveFound)
        {
            possibleMove = display.selectMove();
            for(Move m: board.allMoves(color))
            {
                if(m.equals(possibleMove))
                {
                    legalMoveFound = true;
                }
            }
        }
        return possibleMove;
    }
}
