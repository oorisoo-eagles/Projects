import java.awt.Color;
import java.util.ArrayList;
/**
 * make a Player to play the chess game
 *
 * @author Risa Chokhawala
 * @version April 25, 2024
 */
public abstract class Player
{
    Board board;
    String name;
    Color color;
    
    /**
     * creates a game Player
     * @param b Board where Player is playing
     * @param n name of Player
     * @param c Color of Player
     */
    public Player(Board b, String n, Color c)
    {
        board = b;
        name = n;
        color = c;
    }
    
    /**
     * gets Board which player is in
     * @return Board of player
     */
    public Board getBoard()
    {
        return board;
    }
    
    /**
     * gets player's name
     * @return name of player
     */
    public String getName()
    {
        return name;
    }
    
    /**
     * gets player's color
     * @return color of player
     */
    public Color getColor()
    {
        return color;
    }
    
    /**
     * gets Player's next move in the game
     * @return Move that represents next move of Player
     */
    public abstract Move nextMove();
}
