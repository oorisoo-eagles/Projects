import java.awt.Color;
import java.util.*;
/**
 * Creates a Knight Piece
 *
 * @author Risa Chokhawala
 * @version April 23, 2024
 */
public class Knight extends Piece
{
    /**
     * constructs a new Knight Piece with the given attributes.
     * @param col of Knight
     * @param fileName file name of img used to display Knight
     */
    public Knight(Color col, String fileName)
    {
        super(col, fileName, 3);
    }
    
    /**
     * generates list of locations which Knight can move to
     * @return ArrayList listing locations the Knight can move to
     */
    public ArrayList<Location> destinations()
    {
        ArrayList validDests = new ArrayList<>();
        //can move in L shapes in any direction
        for (int dir=0; dir<360; dir+=90)
        {
            Location temp = getLocation().getAdjacentLocation(dir);
            for (int turn=-45; turn<90; turn+=90)
            {
                if (isValidDestination(temp.getAdjacentLocation(dir + turn)))
                {
                    validDests.add(temp.getAdjacentLocation(dir + turn));
                }
            }
        }
        return validDests;
    }
}
