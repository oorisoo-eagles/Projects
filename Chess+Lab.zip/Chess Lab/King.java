import java.awt.Color;
import java.util.*;
/**
 * Creates a King Piece
 *
 * @author Risa Chokhawala
 * @version April 23, 2024
 */
public class King extends Piece
{
    /**
     * constructs a new King Piece with the given attributes.
     * @param col of King
     * @param fileName file name of img used to display King
     */
    public King(Color col, String fileName)
    {
        super(col, fileName, 1000);
    }
    
    /**
     * generates list of locations which King can move to
     * @return ArrayList listing locations the King can move to
     */
    public ArrayList<Location> destinations()
    {
        ArrayList<Location> potentialNeighborLocs = new ArrayList<>();
        ArrayList<Location> validNeighborLocs = new ArrayList<>();
        int row = getLocation().getRow();
        int col = getLocation().getCol();
        potentialNeighborLocs.add(new Location(row - 1, col));
        potentialNeighborLocs.add(new Location(row + 1, col));
        potentialNeighborLocs.add(new Location(row, col - 1));
        potentialNeighborLocs.add(new Location(row, col + 1));
        potentialNeighborLocs.add(new Location(row - 1, col - 1));
        potentialNeighborLocs.add(new Location(row - 1, col + 1));
        potentialNeighborLocs.add(new Location(row + 1, col - 1));
        potentialNeighborLocs.add(new Location(row + 1, col + 1));
        for(Location loc: potentialNeighborLocs)
        {
            if(isValidDestination(loc))
            {
                validNeighborLocs.add(loc);
            }
        }
        return validNeighborLocs;
    }
}
