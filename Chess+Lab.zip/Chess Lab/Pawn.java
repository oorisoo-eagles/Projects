import java.awt.Color;
import java.util.*;
/**
 * Creates a Pawn Piece
 *
 * @author Risa Chokhawala
 * @version April 23, 2024
 */
public class Pawn extends Piece
{
    /**
     * constructs a new Rook Piece with the given attributes.
     * @param col of Pawn
     * @param fileName file name of img used to display Pawn
     */
    public Pawn(Color col, String fileName)
    {
        super(col, fileName, 1);
    }
    
    /**
     * generates list of locations which Pawn can move to
     * @return ArrayList listing locations the Pawn can move to
     */
    public ArrayList<Location> destinations()
    {
        ArrayList validDests = new ArrayList<>();
        Location loc = getLocation();
        //option to move 1 forward
        Location oneForward = loc.getAdjacentLocation(getDirection());
        if(isValidDestination(oneForward))
        {
            validDests.add(oneForward);
        }
        //option to move 2 forward if it is the first time the pawn is moving
        Location twoForward = oneForward.getAdjacentLocation(getDirection());
        int row = loc.getRow();
        boolean isFirstMove = (getColor().equals(Color.BLACK) && row == 1) ||
            (getColor().equals(Color.WHITE) && row == 6);
        if(isValidDestination(oneForward) && isFirstMove)
        {
            validDests.add(twoForward);
        }
        //option to move 1 diagonal if it there is an enemy piece there
        for (int dir=-45; dir<=45; dir+=90)
        {
            Location diagonal = loc.getAdjacentLocation(getDirection() + dir);
            boolean enemyPieceExists;
            if (super.isValidDestination(diagonal) && 
                getBoard().get(diagonal)!=null)
            {
                enemyPieceExists = true;
            }
            else
            {
                enemyPieceExists = false;
            }
            if(enemyPieceExists)
            {
                validDests.add(diagonal);
            }
        }
        return validDests;
    }
    
    /**
     * returns whether the given loc is a valid destination 
     * for a Pawn piece (it is valid if it is on the board and is empty)
     * @param loc to check
     * @return true if loc is a valid destination and false otherwise
     */
    public boolean isValidDestination(Location loc)
    {
        if(getBoard().isValid(loc) && getBoard().get(loc)==null)
        {
            return true;
        }
        return false;
    }
}
